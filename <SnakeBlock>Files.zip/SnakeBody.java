package main;
import java.awt.Graphics;
/* 
 * SnakeSegment represents one horizontal or vertical segment of a snake
 * the head of this segment is at(headX, headY). The segment is drawn starting
 * from the "head" and proceeding "length" cells in "direction", until
 * it reaches the "tail"
 * */
public class SnakeBody {
	private int headX, headY; //the position of the head's segment
	private int len; //length of this segment
	private Snake.Direction dir;
	
	public SnakeBody(int headX, int headY, int l, Snake.Direction d) {
		this.headX = headX;
		this.headY = headY;
		this.dir = d;
		this.len = l;
	}
	
	//Grow by adding one cell to the head of this segment
	public void grow() {
		++len;
		//need to adjust the headX and headY
		switch (dir) {
		case UP:
			--headY;
			break;
		case RIGHT:
			++headX;
			break;
		case LEFT:
			--headX;
			break;
		case DOWN:
			++headY;
			break;
		}
	}
	//Get the segment's length
		public int getLength() {
			return len;
		}
		
	// Shrink by removing one cell from the tail of this segment
	public void shrink() {
		len+= -1; 
	}
	
	
	
	// Get the X and Y cords of the snake's head
	public int getHeadY() {
		return headY;
	}
	public int getHeadX() {
		return headX;
	}
	
	
	
	//Get the X and  Y cords snake tails
	private int getTailX() {
		if(dir == Snake.Direction.LEFT) {
			return headX + len -1;
		}else if(dir == Snake.Direction.RIGHT) {
			return headX - len +1;
		}
		else { //up and down
			return headX;
		}
		
	}
	
	private int getTailY() {
		if(dir == Snake.Direction.DOWN) {
			return headY - len + 1;
		}else if(dir == Snake.Direction.UP) {
			return headY + len -1;
		}
		else { // left and right
			return headY;
		}
	}
	
	
	// Returns true if the snake segment contains the give cell. used for collision detections
	public boolean contains(int x, int y) {
		switch(dir) {
		case UP:
			return ((x == this.headX) && ((y >= this.headY) && (y <= getTailY() )));
		case RIGHT:
			return ((y == this.headY) && ((x <= this.headX) && (x >= getTailX() )));
		case LEFT:
			return ((y == this.headY) && ((x >= this.headX) && (x <= getTailX() )));
		
		
		case DOWN:
			return ((x == this.headX) && ((y <= this.headY) && (y >= getTailY() )));
		
		}
		return false;
	}
	
	//Draw this segment
	
	public void draw(Graphics g) {
		int xPos = headX;
		int yPos = headY;
		switch(dir) {
		case LEFT:
			for(int i =0; i< len; ++i) {
				g.fill3DRect(
						xPos * GameMain.BODY_SIZE, 
						yPos * GameMain.BODY_SIZE, 
						GameMain.BODY_SIZE - 1, 
						GameMain.BODY_SIZE - 1, true);
				++xPos;
			}
			break;
		case RIGHT:
			for(int i =0; i< len; ++i) {
				g.fill3DRect(
						xPos * GameMain.BODY_SIZE, 
						yPos * GameMain.BODY_SIZE, 
						GameMain.BODY_SIZE - 1, 
						GameMain.BODY_SIZE - 1, true);
				--xPos;
			}
			break;
		case UP:
			for(int i =0; i< len; ++i) {
				g.fill3DRect(
						xPos * GameMain.BODY_SIZE, 
						yPos * GameMain.BODY_SIZE, 
						GameMain.BODY_SIZE - 1, 
						GameMain.BODY_SIZE - 1, true);
				++yPos;
			}
			break;
		case DOWN:
			for(int i =0; i< len; ++i) {
				g.fill3DRect(
						xPos * GameMain.BODY_SIZE, 
						yPos * GameMain.BODY_SIZE, 
						GameMain.BODY_SIZE - 1, 
						GameMain.BODY_SIZE - 1, true);
				--yPos;
			}
			break;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}