package main;

import java.awt.*;
import java.util.*;

// Food is a apple item that the snake can eat. It is placed randomly in the panel.
public class Apple {
	//current apple location(x,y) in cells
	private int xPos;
	private int yPos;
	//color of the apple
	private Color c = Color.RED;
	private Random rand = new Random();
	
	// constructor
	public Apple() {
	
		xPos = -1;
		yPos = -1;
	}
	//Draw class extend
		public void draw(Graphics g) {
			g.setColor(c);
			g.fill3DRect(xPos * GameMain.BODY_SIZE,
					yPos* GameMain.BODY_SIZE, 
					 GameMain.BODY_SIZE,
					 GameMain.BODY_SIZE, 
					true);
	}
	//Stretch a food item. Randomly place inside the panel
	public void stretch() {
		xPos = rand.nextInt(GameMain.COLS - 4) + 2;
		yPos = rand.nextInt(GameMain.ROWS - 4) + 2;
		
	}
	
	public int getY() {
		return yPos;
	}
	//Return the x, y cords of the apple's pos.
		public int getX() {
			return xPos;
		}
		
	
	
	
	
	
	
	
	
	
	
}