package main;

import java.awt.*;
import java.util.*;


//snake class is the identification of what a snake is, basically a head and a tail that grows as the snake eats
public class Snake {
	private static final int INIT_SIZE = 3; //snake's cells
	public static enum Direction {
		UP, DOWN, LEFT, RIGHT
	}
	
	private Color color = Color.GREEN; // snake's body color
	private Color colorHead = Color.BLACK; // snake's head color
	private Snake.Direction dir; // get the current direction of the snake's head
	
	// the snake segments that grows
	private java.util.List<SnakeBody> snakesegs = new ArrayList<SnakeBody>();
	
	private boolean dInfo; //Pending update for a direction change?
	
	private Random r = new Random(); // randomly regenerating a snake
	
	//Regenerate the snake
	public void stretch () {
		snakesegs.clear();
		//Randomly generate a snake inside a pit
		int size = INIT_SIZE; // 3 cells
		int snakeHeadX = r.nextInt(GameMain.COLS - size * 2) + size;
		int snakeHeadY = r.nextInt(GameMain.ROWS - size * 2) + size;
		dir = Snake.Direction
				.values()[r.nextInt(Snake.Direction.values().length)];
		snakesegs.add(new SnakeBody(snakeHeadX, snakeHeadY, size, dir));
		dInfo = false;
		
	}
	
	//Change the direction of the snake, but no 180 degree turn allowed
	public void setDirection(Snake.Direction newD) {
		//checks for direction
		if(!dInfo && (newD != dir)
				&&((newD == Snake.Direction.UP && dir != Snake.Direction.DOWN)
				||(newD == Snake.Direction.DOWN && dir != Snake.Direction.UP)
				||(newD == Snake.Direction.LEFT && dir != Snake.Direction.RIGHT)
				||(newD == Snake.Direction.RIGHT && dir != Snake.Direction.LEFT
				))) {
				SnakeBody headSegment = snakesegs.get(0);
					int x = headSegment.getHeadX();
					int y = headSegment.getHeadY();
					//add a new segment with zero length as the new head segment
					snakesegs.add(0, new SnakeBody(x, y, 0, newD));
					dir = newD;
					dInfo = true; //will be cleared after updated
				}
    
	}
	

	public void update() {
		SnakeBody headSeg = snakesegs.get(0);
		headSeg.grow();
		dInfo = false; 
	}
	
	//SNake grows smaller when it hasn't eaten food in a while
	public void small() {
		SnakeBody tailSeg = snakesegs.get(snakesegs.size()-1);
		tailSeg.shrink();
		if(tailSeg.getLength() == 0) {
			snakesegs.remove(tailSeg);
		}
	}
	
	//Get the X,Y coordinate of the cell that contains the snake's head segment
	public int getHeadX() {
		return snakesegs.get(0).getHeadX();
	}
	public int getHeadY() {
		return snakesegs.get(0).getHeadY();
	}
	
	// checks for snake body 
	public boolean contains(int x, int y) {
		for(int i =0; i< snakesegs.size(); ++i) {
			SnakeBody segment = snakesegs.get(i);
			if(segment.contains(x,y)) {
				return true;
			}
			
		}
		return false;
	}
	
	// checks if snake eats itself
	public boolean selfEatten() {
		int sHeadY = getHeadY();
		int sHeadX = getHeadX();
		for(int i =3; i <snakesegs.size(); ++i) {
			SnakeBody segment = snakesegs.get(i);
			if(segment.contains(sHeadX, sHeadY)) {
				return true;
			}
		}
		return false;
	}
	
	// Draw itself
	public void draw(Graphics G) {
		G.setColor(color);
		for(int i = 0; i< snakesegs.size(); ++i) {
			snakesegs.get(i).draw(G); //draw body segments 
		}
		
		if(snakesegs.size() > 0) {
			G.setColor(colorHead);
			G.fill3DRect(
					getHeadX() * GameMain.BODY_SIZE, 
					getHeadY() * GameMain.BODY_SIZE, 
					GameMain.BODY_SIZE - 1, 
					GameMain.BODY_SIZE - 1,
					true
					);
		}
	}
	
	
	
	
	
	
}

	
	
	
	
	
	
	