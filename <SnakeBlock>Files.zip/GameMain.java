package main;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//main class for the game
public class GameMain extends JPanel{

	private static final long serialVersionUID = 1L;
	//Define constants for the game
	static final String TITLE = "Snake Block";
	//rows cells)
	static final int ROWS = 50;
	//cols (cells)
	static final int COLS = 50;
	//Cell size ( pixels)
	static final int BODY_SIZE = 15;
	//width and height of the game panel
	static final int CANVAS_HEIGHT = BODY_SIZE * ROWS;
	static final int CANVAS_WIDTH = BODY_SIZE * COLS;
	
	//updates per seconds
	static final int UPDATE_PER_SEC = 3;
	static final long UPDATE_PERIOD = 1000000000L / UPDATE_PER_SEC;
	
	
	
	enum GameState {
		INITIALIZED, PLAY, PAUSE, GAMEOVER
	}
	
	//Declare menubar
	static JMenuBar optionBar;
	
	// current state of the game
	static GameState status;
	
	//Define instance variables for the game objects
	private Apple apple;
	private Snake snake;
	
	// Handle for the custom drawing panel and UI components
	private GameCanvas pan;
	private ControlPanel controlPan;
	private JLabel lblScore;
	int score = 0;
	
	// Constructor 
	public GameMain() {
	//	establish game
		gameInit();
		
		
		setLayout(new BorderLayout());
		//drawing panel
		pan = new GameCanvas();
		pan.setPreferredSize(new Dimension(CANVAS_WIDTH,CANVAS_HEIGHT));
		add(pan, BorderLayout.CENTER);
		
		//control panel to the bottom
		controlPan = new ControlPanel();
		add(controlPan, BorderLayout.SOUTH);
		
		//add the menu bar
		setupMenuBar();
		
		// start the game
		gameStart();
	}
	
	//Game Code
	public void gameInit() {
		//Create a new snake and a food item
		status = GameState.INITIALIZED;
		snake = new Snake();
		apple = new Apple();
	
		
	}
	
	
	// to start and restart the game
	public void gameStart() {
		// Create a new thread
		Thread gameThread = new Thread() {

			public void run() {
				gameLoop();
			}
		};
		gameThread.start();
	}
	
	// run the game loop here
	private void gameLoop() {
		//Stretches and resets the game objects for a new game
		if(status == GameState.INITIALIZED || status == GameState.GAMEOVER) {
			//Generate a new snake and a food item
			snake.stretch ();
			
			//Stretch if apple placed under the snake
			int xPos;
			int yPos;
			do {
				apple.stretch();
				xPos = apple.getX();
				yPos = apple.getY();
			}while(snake.contains(xPos,yPos));
			
			status = GameState.PLAY;
			
		}
		//Game loop
		long startTime;
		long timeGone;
		long timeRemaining; //in milliesecs*
		while(status != GameState.GAMEOVER) {
			startTime = System.nanoTime();
			if(status == GameState.PLAY) {
				//update the state and position of all the game object
				gameUpdate();
			}
			// Refresh the display
			repaint();
			//Delay timer
			timeGone = System.nanoTime() - startTime;
	
			timeRemaining = (UPDATE_PERIOD - timeGone)/ 1000000;
			if(timeRemaining < 10) timeRemaining = 10; //set a minimum
			try {
				Thread.sleep(timeRemaining);
				}catch(InterruptedException ex) {}
			
		}
	}
	
	//update the state and pos. of all the snake and apple
	public void gameUpdate() {
		snake.update();
		collision();
		
	}
	
	//Collision detection and response
	public void collision() {
		// check if the snake has eaten
				int snakeHeadX = snake.getHeadX();
				int snakeHeadY = snake.getHeadY();
				
				if(snakeHeadX == apple.getX() && snakeHeadY == apple.getY()) {
					//update score when snake eats apple
					score = score + 1;
					lblScore.setText("Score: "+score);
					
					//food eaten, grow one
					int xPos;
					int yPos;
					do {
						apple.stretch();
						xPos = apple.getX();
						yPos = apple.getY();
					}while(snake.contains(xPos, yPos));
				}else {
					
					snake.small();
				}
				
				// Check if the snake moves out of bounds
				if(!pan.contains(snakeHeadX, snakeHeadY)) {
					status = GameState.GAMEOVER;
					score = 0;
					lblScore.setText("Score: "+score);
					return;
				}
				
				// Check if the snake eats itself
				if(snake.selfEatten()) {
					status = GameState.GAMEOVER;
				
					score = 0;
					lblScore.setText("Score: "+score);
					return;
				}
			}
	
	// Refresh the display.
	private void gameDraw(Graphics G) {
		//draw game objects
		 apple.draw(G);
		 snake.draw(G);		
		G.setColor(Color.BLACK);
		G.setFont(new Font("Dialog", Font.PLAIN, 14));
		G.drawString("Snake: ("+snake.getHeadX() + "," + snake.getHeadY() + ")",5, 25);
		
		if(status == GameState.GAMEOVER) {
			G.setColor(Color.RED);
			G.setFont(new Font("Verdana", Font.BOLD, 50));
			G.drawString("GAME OVER!", 200, CANVAS_HEIGHT / 2);
		}
		
	}
	
	//Listens to a key-pressed event. Update the current state
	public void gameKeyPressed(int keyCode) {
		switch (keyCode) {
		case KeyEvent.VK_UP:
			snake.setDirection(Snake.Direction.UP);
			break;
		case KeyEvent.VK_RIGHT:
			snake.setDirection(Snake.Direction.RIGHT);
			break;
		case KeyEvent.VK_LEFT:
			snake.setDirection(Snake.Direction.LEFT);
			break;
		case KeyEvent.VK_DOWN:
			snake.setDirection(Snake.Direction.DOWN);
			break;
	
		}
	}
	
	
	//Game Control Panel with Start, Stop, Pause and Refresh/Debug buttons
	class ControlPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		private JButton butStartPause;
		private JButton butStop;
		private JButton butDebug;
		
	
		
		public ControlPanel () {
			this.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 10));
			
			butStartPause = new JButton();
			butStartPause.setText("      Play/Pause      ");
			butStartPause.setCursor(new Cursor(Cursor.HAND_CURSOR));
			butStartPause.setEnabled(true);
			add(butStartPause);
			
			butStop = new JButton();
			butStop.setText("    Stop Game    ");
			butStop.setCursor(new Cursor(Cursor.HAND_CURSOR));
			butStop.setEnabled(true);
			add(butStop);
			
			butDebug = new JButton();
			butDebug.setText("    Debug    ");
			butDebug.setCursor(new Cursor(Cursor.HAND_CURSOR));
			butDebug.setEnabled(true);
			add(butDebug);
			
			//default score 0
			lblScore = new JLabel("Score: 0");
			add(lblScore);
			
			//notifies code when buttons are clicked
			butStartPause.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					switch(status) {
					case INITIALIZED:
					case GAMEOVER:
					
						butStartPause.setText("Start");
						gameStart();
					
						//default score
						score = 0;
						lblScore.setText("Score: "+score);
						break;
					case PLAY:
						status = GameState.PAUSE;
					
						butStartPause.setText("Start");
	
						
						break;
					case PAUSE:
						status = GameState.PLAY;
						
						butStartPause.setText("Pause");
					
						
						break;
					}
					butStop.setEnabled(true);
					pan.requestFocus();
					
				}
			});
			
			butStop.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					status = GameState.GAMEOVER;
					butStartPause.setEnabled(true);
					butStop.setEnabled(false);
					butStartPause.setText("Start");
					
					
				}
			});
			
			butDebug.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					pan.requestFocus();
					
					
					
				}
			});
			
		}
		
		// Reset control for a new game
					public void reset() {
						
						butStartPause.setEnabled(true);
						butStop.setEnabled(false);
					}
	}
	
	// Custom drawing panel
	class GameCanvas extends JPanel implements KeyListener {

		private static final long serialVersionUID = 1L;
		//constructor
		public GameCanvas() {
			setFocusable(true); // receive key-events
			requestFocus();
			addKeyListener(this);
		}
		
		
		//recalls repaint()
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			//paint background
			//set background color
			setBackground(Color.decode("0x5F219F"));
			
			//draw the game objects
			gameDraw(g);
		}
		
		//KeyEvent handlers
		@Override
		public void keyPressed(KeyEvent e) {
			gameKeyPressed(e.getKeyCode());
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		// Check if this pit contains the given(x,y) for collision detection
		public boolean contains (int x, int y) {
			if((y>=COLS)||(y<0) ){
				return false;
			}
			if((x>=ROWS)|| (x<0)) {
				return false;
			}
			return true;
		}
		
	}
	// Helper function to setup the menubar
	private void setupMenuBar() {
		JMenu hub; //a menu in the menu bar
		JMenuItem hubItem; // a regular menu-item in a menu
		
		optionBar = new JMenuBar();
		
		
		
		// Menu for helping
		hub = new JMenu("Help");
		hub.setMnemonic(KeyEvent.VK_H);
		optionBar.add(hub);
		
		hubItem = new JMenuItem("Help Contents", KeyEvent.VK_H);
		hub.add(hubItem);
		hubItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String message = "Arrow keys to change direction\n";
				JOptionPane.showMessageDialog(GameMain.this, message,
						"Instructions", JOptionPane.PLAIN_MESSAGE);
					
				
			}
			
		});
		
		//  Game menu
				hub = new JMenu("Game");
				hub.setMnemonic(KeyEvent.VK_G);
				optionBar.add(hub);
				
				hubItem = new JMenuItem("New Game", KeyEvent.VK_N);
				hub.add(hubItem);
				hubItem.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// stop the game when needed
						if(status == GameState.PLAY || status == GameState.PAUSE) {
							status = GameState.GAMEOVER;
						}
						gameStart();
						controlPan.reset();
					}
					
				});
		
		hubItem = new JMenuItem("Game Details", KeyEvent.VK_A);
		hub.add(hubItem);
		hubItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(GameMain.this, 
						"The snake hunting is the recreation of the orginal game: SNAKE. The user's gaol is to grow longer from eating\n"
						+ " the food located in the game and not die by hitting the walls or itself.",
						"About", JOptionPane.PLAIN_MESSAGE);
				
			}
			
		});
	}
	
	// main code
	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame mainFrame = new JFrame(TITLE);
				// main JPanel as content pan
				mainFrame.setContentPane(new GameMain());
				mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				mainFrame.pack();
				//show the frame
				mainFrame.setJMenuBar(optionBar);
				mainFrame.setVisible(true);
				//centers the window
				mainFrame.setLocationRelativeTo(null);
				
			}
		});
	}
}